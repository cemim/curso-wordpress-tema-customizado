<?php

function tema_child_scripts(){
    wp_enqueue_style('theme-style', get_template_directory_uri() . '/style.css');//Identificador do estilo do tema pai

    wp_enqueue_style('theme-child-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version')); // Sobrescreve o css do tema Pai
}

add_action('wp_enqueue_scripts', 'tema_child_scripts');