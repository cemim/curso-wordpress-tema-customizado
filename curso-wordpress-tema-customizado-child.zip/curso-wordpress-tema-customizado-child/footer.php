    <footer class="site-footer">
        <div class="container">
            <nav class="footer-menu">
                <?php 
                    wp_nav_menu(array(
                        'theme_location' => 'theme_footer_menu',
                        'depth' => 1
                    )) ;
                ?>
            </nav>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>